try:
    import torch
    assert torch.cuda.is_available(), "CUDA is not available."
except ImportError:
    raise ImportError(
        "\n\nPyTorch is not installed. \n"
        "Please install it manually from https://pytorch.org according to your CUDA version \n"
        "before installing or using the 'faithcontour' library.\n"
    )

# Expose the main API functions to the top-level package
from .api import FCT_encoder, FCT_decoder

# Expose key utility classes
from .utils.grid import *
from .utils.mesh import normalize_mesh, normalize_mesh_max_fill
