import torch
import math
import numpy as np
from typing import Optional, Tuple, Iterator

CUBE_EDGES = np.array([
    # z=0 面环（0-2-6-4）
    [0, 2], [2, 6], [6, 4], [4, 0],
    # z=1 面环（1-3-7-5）
    [1, 3], [3, 7], [7, 5], [5, 1],
    # 垂直边（沿 z）
    (0, 1), (2, 3), (6, 7), (4, 5),
], dtype=np.int64)
CUBE_EDGES = torch.from_numpy(CUBE_EDGES)

CUBE_FACES = torch.tensor([
    [0, 2, 6, 4],  # -Z 面 (z=0, front face)
    [1, 5, 7, 3],  # +Z 面 (z=1, back face)
    [0, 1, 3, 2],  # -X 面 (x=0, left face)
    [4, 6, 7, 5],  # +X 面 (x=1, right face)
    [0, 4, 5, 1],  # -Y 面 (y=0, bottom face)
    [2, 3, 7, 6],  # +Y 面 (y=1, top face)
], dtype=torch.long)

CUBE_FACE_FLUX_INDICES = torch.tensor([
            # 对应 -Z 面 [0, 2, 6, 4] 的4条边 (0->2, 2->6, 6->4, 4->0)
            # 在 CUBE_EDGES 中，边(2,0)索引为3, 边(6,2)索引为2, ...
            [3, 2, 1, 0],   # -Z face (front)
            # 对应 +Z 面 [1, 5, 7, 3] 的4条边 (1->5, 5->7, 7->3, 3->1)
            [4, 5, 6, 7],   # +Z face (back)
            # 对应 -X 面 [0, 1, 3, 2] 的4条边 (0->1, 1->3, 3->2, 2->0)
            [8, 10, 3, 10], # -X face (left)  <-- 注意：(3,2) 和 (2,3) 共享索引10
            # 对应 +X 面 [4, 6, 7, 5] 的4条边 (4->6, 6->7, 7->5, 5->4)
            [1, 11, 5, 9], # +X face (right) <-- 注意：(5,4) 和 (4,5) 共享索引9
            # 对应 -Y 面 [0, 4, 5, 1] 的4条边 (0->4, 4->5, 5->1, 1->0)
            [0, 9, 4, 8],  # -Y face (bottom)
            # 对应 +Y 面 [2, 3, 7, 6] 的4条边 (2->3, 3->7, 7->6, 6->2)
            [10, 6, 11, 2],  # +Y face (top)
        ], dtype=torch.long)

# (The GridExtent class remains the same as before)
class GridExtent:
    """
    原/对偶网格工具（内存友好）：
      - 原网格范围 [-1, 1]，单元边长 h=2/res
      - 仅持有 1D 坐标；其余按需计算
      - 当不传索引时，默认返回“全部”
    """
    def __init__(self, res: int,
                 device: torch.device | str = "cpu",
                 dtype: torch.dtype = torch.float32,
                 index_dtype: Optional[torch.dtype] = None):
        if not isinstance(res, int) or res < 1:
            raise ValueError("res must be a positive int")
        self.res = int(res)
        self.p_num = res + 1              # 原顶点每轴数
        self.d_ext_num = res + 2          # 外扩对偶顶点每轴数
        self.h = 2.0 / res

        self.device = torch.device(device)
        self.dtype = dtype

        self.dual_num = self.p_num**3   # 对偶立方体数
        self.primal_num = res**3        # 原立方体数

        # 索引 dtype：能用 int32 就别用 int64
        if index_dtype is None:
            max_idx = self.d_ext_num**3 - 1 # Use the largest possible index
            self.index_dtype = torch.int32 if max_idx <= (2**31 - 1) else torch.int64
        else:
            self.index_dtype = index_dtype

        # 1D 坐标
        self.p_coords_1d = torch.linspace(-1.0, 1.0, self.p_num, device=self.device, dtype=self.dtype)
        self.d_ext_coords_1d = torch.linspace(-1.0 - self.h/2.0, 1.0 + self.h/2.0,
                                              self.d_ext_num, device=self.device, dtype=self.dtype)

        # 角点偏移（8×3）
        self._corner_offsets = torch.tensor([
            [0,0,0],[0,0,1],[0,1,0],[0,1,1],
            [1,0,0],[1,0,1],[1,1,0],[1,1,1]
        ], device=self.device, dtype=self.index_dtype)

        # 对偶单元中心相对偏移（与上面对应；{0,-1}）
        self._cell_offsets_dual = torch.tensor([
            [ 0,  0,  0],[ 0,  0, -1],[ 0, -1,  0],[ 0, -1, -1],
            [-1,  0,  0],[-1,  0, -1],[-1, -1,  0],[-1, -1, -1]
        ], device=self.device, dtype=self.index_dtype)

        # 线性化乘数
        self._p_mul    = torch.tensor([self.p_num*self.p_num, self.p_num, 1], device=self.device, dtype=self.index_dtype)
        self._d_ext_mul= torch.tensor([self.d_ext_num*self.d_ext_num, self.d_ext_num, 1], device=self.device, dtype=self.index_dtype)

        # 立方体12条边的定义 (基于_corner_offsets的局部索引)
        self.CUBE_EDGES = CUBE_EDGES.to(self.device)

        # 6个面中心的坐标
        self.CUBE_FACES = CUBE_FACES.to(self.device)

        self._face_neighbor_offsets = torch.tensor([
            [0, 0, -1],  # Corresponds to CUBE_FACES[0] (-Z)
            [0, 0, 1],   # Corresponds to CUBE_FACES[1] (+Z)
            [-1, 0, 0],  # Corresponds to CUBE_FACES[2] (-X)
            [1, 0, 0],   # Corresponds to CUBE_FACES[3] (+X)
            [0, -1, 0],  # Corresponds to CUBE_FACES[4] (-Y)
            [0, 1, 0],   # Corresponds to CUBE_FACES[5] (+Y)
        ], device=self.device, dtype=self.index_dtype)

        self.CUBE_FACE_FLUX_INDICES = CUBE_FACE_FLUX_INDICES.to(self.device)

        # 为 x, y, z 三个方向的 primal edge 定义其 dual face 的顶点偏移
        # key: 方向向量 (元组形式)
        # value: 4个外扩对偶顶点的 ijk 偏移量 (相对于边的起始原始顶点)
        self._dual_face_v_offsets = {
            (1, 0, 0): torch.tensor([[1,0,0], [1,1,0], [1,1,1], [1,0,1]], device=self.device, dtype=self.index_dtype), # +X face
            (0, 1, 0): torch.tensor([[0,1,0], [0,1,1], [1,1,1], [1,1,0]], device=self.device, dtype=self.index_dtype), # +Y face
            (0, 0, 1): torch.tensor([[0,0,1], [1,0,1], [1,1,1], [0,1,1]], device=self.device, dtype=self.index_dtype), # +Z face
        }
        # 为负方向也添加映射
        self._dual_face_v_offsets[(-1, 0, 0)] = self._dual_face_v_offsets[(1, 0, 0)] - torch.tensor([1,0,0], device=self.device, dtype=self.index_dtype)
        self._dual_face_v_offsets[(0, -1, 0)] = self._dual_face_v_offsets[(0, 1, 0)] - torch.tensor([0,1,0], device=self.device, dtype=self.index_dtype)
        self._dual_face_v_offsets[(0, 0, -1)] = self._dual_face_v_offsets[(0, 0, 1)] - torch.tensor([0,0,1], device=self.device, dtype=self.index_dtype)

        # --- 为向量化操作预计算辅助张量 ---
        # 1. 每条边的起始角点偏移 (12, 3)
        self._edge_start_corner_offsets = self._corner_offsets[self.CUBE_EDGES[:, 0]]

        # 2. 每条边对应的对偶面顶点偏移 (12, 4, 3)
        directions = self._corner_offsets[self.CUBE_EDGES[:, 1]] - self._edge_start_corner_offsets
        offsets_list = [self._dual_face_v_offsets[tuple(d.tolist())] for d in directions]
        self._d_ext_v_offsets_all_edges = torch.stack(offsets_list, dim=0)


    # ---------- 全量索引 ----------
    def all_primal_cube_indices(self) -> torch.Tensor:
        """[0 .. res^3-1]"""
        return torch.arange(self.res**3, device=self.device, dtype=self.index_dtype)

    def all_dual_cube_indices(self) -> torch.Tensor:
        """[0 .. p_num^3-1]（对偶立方体以原顶点网格索引表示）"""
        return torch.arange(self.p_num**3, device=self.device, dtype=self.index_dtype)

    # ---------- 基础 ravel/unravel ----------
    def ravel_ijk(self, ijk: torch.Tensor, dims: Tuple[int,int,int]) -> torch.Tensor:
        nx, ny, nz = dims
        mul = torch.tensor([ny*nz, nz, 1], device=self.device, dtype=self.index_dtype)
        ijk = ijk.to(self.index_dtype)
        return (ijk * mul).sum(dim=-1)

    def unravel_idx(self, idx: torch.Tensor, dims: Tuple[int,int,int]) -> torch.Tensor:
        nx, ny, nz = dims
        idx = idx.to(self.index_dtype)
        i = torch.div(idx, ny*nz, rounding_mode='floor')
        rem = idx - i*(ny*nz)
        j = torch.div(rem, nz, rounding_mode='floor')
        k = rem - j*nz
        return torch.stack([i, j, k], dim=-1)

    # ---------- 原始立方体 ----------
    def primal_cube_indices_ijk(self, cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        """线性立方体索引 -> (i,j,k)。不传则返回全部."""
        if cube_idx is None:
            cube_idx = self.all_primal_cube_indices()
        dims = (self.res, self.res, self.res)
        return self.unravel_idx(cube_idx, dims)

    def primal_cube_corner_vertex_indices(self, cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        """
        原立方体 -> 8 原顶点线性索引，形状 (B,8)；不传则 B=res^3。
        注意：全量时内存很大（~ 8 * res^3 * sizeof(int)）
        """
        if cube_idx is None:
            cube_idx = self.all_primal_cube_indices()
        ijk = self.primal_cube_indices_ijk(cube_idx.to(self.device)).to(self.index_dtype)   # (B,3)
        corners = ijk[:, None, :] + self._corner_offsets[None, :, :]           # (B,8,3)
        vidx = (corners * self._p_mul[None, None, :]).sum(dim=-1)              # (B,8)
        return vidx

    def primal_vertex_coords_from_indices(self, v_idx: torch.Tensor) -> torch.Tensor:
        """原顶点线性索引 -> 坐标 (B,3)"""
        ijk = self.unravel_idx(v_idx, (self.p_num, self.p_num, self.p_num)).to(torch.long)
        x = self.p_coords_1d.index_select(0, ijk[..., 0].flatten()).view(ijk.shape[:-1])
        y = self.p_coords_1d.index_select(0, ijk[..., 1].flatten()).view(ijk.shape[:-1])
        z = self.p_coords_1d.index_select(0, ijk[..., 2].flatten()).view(ijk.shape[:-1])
        return torch.stack([x, y, z], dim=-1)

    def primal_cube_aabbs_minmax(self, cube_idx: Optional[torch.Tensor]=None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        直接公式算 AABB（min + [0,0,0], max = min + h）。
        不传则对全部立方体返回 (res^3,3)。
        """
        if cube_idx is None:
            cube_idx = self.all_primal_cube_indices()
        ijk = self.primal_cube_indices_ijk(cube_idx).to(torch.long)
        xmin = self.p_coords_1d.index_select(0, ijk[..., 0].flatten()).view(ijk.shape[:-1])
        ymin = self.p_coords_1d.index_select(0, ijk[..., 1].flatten()).view(ijk.shape[:-1])
        zmin = self.p_coords_1d.index_select(0, ijk[..., 2].flatten()).view(ijk.shape[:-1])
        mins = torch.stack([xmin, ymin, zmin], dim=-1)
        maxs = mins + self.h
        return mins.to(self.dtype), maxs.to(self.dtype)

    def primal_cube_aabbs_centers(self, cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        """返回原始立方体中心点坐标。"""
        mins, maxs = self.primal_cube_aabbs_minmax(cube_idx)
        return (mins + maxs) * 0.5

    def primal_cubes_to_dual_cubes_indices(self, cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        """
        原立方体 -> 8 对偶立方体（以原顶点网格线性索引表示）。不传则返回全部 (res^3,8)
        """
        return self.primal_cube_corner_vertex_indices(cube_idx)

    # ---------- 对偶立方体 & 外扩对偶顶点 ----------
    def dual_cubes_to_dual_vertices_ext_indices(self, dual_cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        """
        对偶立方体（[0..p_num^3)）-> 8 外扩对偶顶点线性索引（[0..d_ext_num^3)）。不传则全量 (p_num^3,8)
        """
        if dual_cube_idx is None:
            dual_cube_idx = self.all_dual_cube_indices()
        ijk = self.unravel_idx(dual_cube_idx, (self.p_num, self.p_num, self.p_num)).to(self.index_dtype)
        base = ijk[:, None, :] + self._cell_offsets_dual[None, :, :] + 1       # (B,8,3)
        vidx = (base * self._d_ext_mul[None, None, :]).sum(dim=-1)             # (B,8)
        return vidx

    def dual_vertices_ext_coords_from_indices(self, v_idx: torch.Tensor) -> torch.Tensor:
        """外扩对偶顶点线性索引 -> 坐标 (B,3)"""
        ijk = self.unravel_idx(v_idx, (self.d_ext_num, self.d_ext_num, self.d_ext_num)).to(torch.long)
        x = self.d_ext_coords_1d.index_select(0, ijk[..., 0].flatten()).view(ijk.shape[:-1])
        y = self.d_ext_coords_1d.index_select(0, ijk[..., 1].flatten()).view(ijk.shape[:-1])
        z = self.d_ext_coords_1d.index_select(0, ijk[..., 2].flatten()).view(ijk.shape[:-1])
        return torch.stack([x, y, z], dim=-1)


    def get_primal_face_dual_vertex_pairs(self, primal_cube_idx: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        For each primal cube, finds the pair of extended dual vertex indices that
        represent the centers of the cube and its neighbor across each of the 6 faces.

        The order of the 6 faces/neighbors corresponds to the order in CUBE_FACES:
        -Z, +Z, -X, +X, -Y, +Y.
        
        Thanks to the extended dual grid design (d_ext_num = res + 2), every
        neighboring dual vertex has a valid index.

        Args:
            primal_cube_idx (Optional[torch.Tensor]): A 1D tensor of primal cube
                linear indices. If None, computes for all primal cubes.

        Returns:
            torch.Tensor: A tensor of shape (B, 6, 2) where B is the number
                of input cubes. Each pair contains [center_dual_vertex_idx,
                neighbor_center_dual_vertex_idx].
        """
        if primal_cube_idx is None:
            primal_cube_idx = self.all_primal_cube_indices()

        if not isinstance(primal_cube_idx, torch.Tensor) or primal_cube_idx.dim() != 1:
            raise TypeError("Input must be a 1D torch.Tensor of primal cube indices.")

        B = primal_cube_idx.numel()
        if B == 0:
            return torch.empty(0, 6, 2, dtype=self.index_dtype, device=self.device)

        # 1. Get the ijk of the input primal cubes.
        base_primal_ijks = self.primal_cube_indices_ijk(primal_cube_idx)

        # 2. Find the ijk of the extended dual vertex at the center of each primal cube.
        #    The +1 offset maps from the primal cube grid to the extended dual vertex grid.
        center_dual_v_ijks = base_primal_ijks + 1

        # 3. Find the ijk of the 6 neighboring primal cubes.
        neighbor_primal_ijks = base_primal_ijks.unsqueeze(1) + self._face_neighbor_offsets.unsqueeze(0)
        
        # 4. Find the ijk of the extended dual vertices at the center of the neighbors.
        neighbor_dual_v_ijks = neighbor_primal_ijks + 1

        # 5. Convert all dual vertex ijk coordinates to linear indices.
        #    No boundary check is needed due to the extended grid's halo layer.
        dims = (self.d_ext_num, self.d_ext_num, self.d_ext_num)
        
        center_dual_v_indices = self.ravel_ijk(center_dual_v_ijks, dims)
        
        flat_neighbor_dual_v_ijks = neighbor_dual_v_ijks.view(-1, 3)
        flat_neighbor_indices = self.ravel_ijk(flat_neighbor_dual_v_ijks, dims)
        neighbor_dual_v_indices = flat_neighbor_indices.view(B, 6)
        
        # 6. Create the final pairs.
        center_indices_expanded = center_dual_v_indices.unsqueeze(1).expand(-1, 6)
        pairs = torch.stack([center_indices_expanded, neighbor_dual_v_indices], dim=-1)

        return pairs

    def dual_cube_aabbs_minmax(self, dual_cube_idx: Optional[torch.Tensor]=None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        对偶立方体（以原顶点网格线性索引表示） → 其 AABB 的 (min, max)。
        """
        if dual_cube_idx is None:
            dual_cube_idx = self.all_dual_cube_indices()
        centers = self.primal_vertex_coords_from_indices(dual_cube_idx)
        half = self.h * 0.5
        return centers - half, centers + half

    def dual_cube_aabbs_centers(self, dual_cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        """返回对偶立方体中心点坐标 (等同于其对应的原顶点坐标)。"""
        if dual_cube_idx is None:
            dual_cube_idx = self.all_dual_cube_indices()
        return self.primal_vertex_coords_from_indices(dual_cube_idx)

    # ---------- 分块迭代 ----------
    def iter_primal_all(self, chunk: int) -> Iterator[tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]]:
        """
        迭代全量原立方体，按块产出：
          yield (cube_idx_chunk, Fp_chunk(·,8), aabb_min_chunk(·,3), aabb_max_chunk(·,3))
        """
        all_idx = self.all_primal_cube_indices()
        for s in range(0, all_idx.numel(), chunk):
            idx = all_idx[s:s+chunk]
            Fp = self.primal_cube_corner_vertex_indices(idx)
            a_min, a_max = self.primal_cube_aabbs_minmax(idx)
            yield idx, Fp, a_min, a_max

    def iter_dual_all(self, chunk: int) -> Iterator[tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]]:
        """
        迭代全量对偶立方体，按块产出：
        yield (dual_idx_chunk, Fd_chunk(·,8), aabb_min_chunk(·,3), aabb_max_chunk(·,3))
        """
        all_idx = self.all_dual_cube_indices()
        for s in range(0, all_idx.numel(), chunk):
            idx = all_idx[s:s+chunk]
            Fd  = self.dual_cubes_to_dual_vertices_ext_indices(idx)
            a_min, a_max = self.dual_cube_aabbs_minmax(idx)
            yield idx, Fd, a_min, a_max

    # ---------- 新增方法：获取 Primal Edge 对应的 Dual Face ----------
    
    def get_flux_dualvertsidx_from_primal(self, primal_cube_idx: torch.Tensor=None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        (向量化版) 为一批原始立方体，计算其12条边对应的12个对偶“挡板面”。

        参数:
          primal_cube_idx (Tensor): 形状为 (B,) 的一维张量，包含 B 个原始立方体的线性索引。

        返回:
          - dual_face_vertices (Tensor[B, 12, 4]): B个立方体，每个12个面，每个面4个顶点的线性索引。
          - dual_cube_pairs (Tensor[B, 12, 2]): B个立方体，每个12个面所分隔的对偶立方体的局部索引对(0-7)。
        """
        if not isinstance(primal_cube_idx, torch.Tensor) or primal_cube_idx.dim() != 1:
            raise TypeError("Input must be a 1D torch.Tensor of primal cube indices.")

        B = primal_cube_idx.numel()
        if B == 0:
            return torch.empty(0, 12, 4, dtype=self.index_dtype, device=self.device), \
                   torch.empty(0, 12, 2, dtype=torch.long, device=self.device)
        

        # 1. 获取所有 B 个立方体的 "基准" ijk 坐标 (B, 3)
        base_primal_ijks = self.primal_cube_indices_ijk(primal_cube_idx)

        # 2. 计算所有边的起始点 ijk 坐标 (广播: (B, 1, 3) + (1, 12, 3) -> (B, 12, 3))
        start_p_ijks = base_primal_ijks.unsqueeze(1) + self._edge_start_corner_offsets.unsqueeze(0)

        # 3. 计算所有对偶面顶点的 ijk 坐标 (广播: (B, 12, 1, 3) + (1, 12, 4, 3) -> (B, 12, 4, 3))
        dual_v_ijks = start_p_ijks.unsqueeze(2) + self._d_ext_v_offsets_all_edges.unsqueeze(0)

        # 4. 将所有 ijk 坐标大批量转换为线性索引
        dims = (self.d_ext_num, self.d_ext_num, self.d_ext_num)
        flat_dual_v_ijks = dual_v_ijks.view(-1, 3)
        flat_linear_indices = self.ravel_ijk(flat_dual_v_ijks, dims)
        dual_face_vertices = flat_linear_indices.view(B, 12, 4)

        # 5. 获取每个 primal cube 周围8个 dual cubes 的【绝对索引】
        #    形状: (B, 8)
        all_surrounding_dual_indices = self.primal_cubes_to_dual_cubes_indices(primal_cube_idx)
        
        # 6. 使用 CUBE_EDGES 的局部索引 (0-7) 来从上面的绝对索引中挑选出正确的配对
        #    CUBE_EDGES[:, 0] 是12条边的起始点局部索引
        #    CUBE_EDGES[:, 1] 是12条边的结束点局部索引
        
        # 获取所有边的起始点的绝对索引，形状: (B, 12)
        v0_global = all_surrounding_dual_indices[:, self.CUBE_EDGES[:, 0]]
        
        # 获取所有边的结束点的绝对索引，形状: (B, 12)
        v1_global = all_surrounding_dual_indices[:, self.CUBE_EDGES[:, 1]]
        
        # 将它们堆叠起来，形成最终的配对，形状: (B, 12, 2)
        absolute_dual_pairs = torch.stack([v0_global, v1_global], dim=2)
        # ==================== 修改部分结束 ====================

        return dual_face_vertices, absolute_dual_pairs
    

    def primal_level_size(self, level: int) -> int:
        """某层的每轴单元数 = 2^level"""
        return 1 << level

    def primal_level_cells(self, level: int) -> int:
        """某层总单元数 = (2^level)^3"""
        s = 1 << level
        return s * s * s
    
    def primal_cube_aabbs_centers(self, cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        if cube_idx is None:
            cube_idx = torch.arange(self.primal_num, device=self.device, dtype=self.index_dtype)
        mins, maxs = self.primal_cube_aabbs_minmax(cube_idx)
        return (mins + maxs) * 0.5
    
    def dual_cube_aabbs_centers(self, dual_cube_idx: Optional[torch.Tensor]=None) -> torch.Tensor:
        if dual_cube_idx is None:
            dual_cube_idx = torch.arange(self.dual_num, device=self.device, dtype=self.index_dtype)
        mins, maxs = self.dual_cube_aabbs_minmax(dual_cube_idx)
        return (mins + maxs) * 0.5

    def get_semiaxis_dualverts_pairs_from_primal(self, primal_cube_idx: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        For each primal cube, finds the pair of extended dual vertex indices that
        represent the centers of the cube and its neighbor across each of the 6 faces.

        The order of the 6 faces/neighbors corresponds to the order in CUBE_FACES:
        -Z, +Z, -X, +X, -Y, +Y.
        
        Thanks to the extended dual grid design (d_ext_num = res + 2), every
        neighboring dual vertex has a valid index.

        Args:
            primal_cube_idx (Optional[torch.Tensor]): A 1D tensor of primal cube
                linear indices. If None, computes for all primal cubes.

        Returns:
            torch.Tensor: A tensor of shape (B, 6, 2) where B is the number
                of input cubes. Each pair contains [center_dual_vertex_idx,
                neighbor_center_dual_vertex_idx].
        """
        if primal_cube_idx is None:
            primal_cube_idx = self.all_primal_cube_indices()

        if not isinstance(primal_cube_idx, torch.Tensor) or primal_cube_idx.dim() != 1:
            raise TypeError("Input must be a 1D torch.Tensor of primal cube indices.")

        B = primal_cube_idx.numel()
        if B == 0:
            return torch.empty(0, 6, 2, dtype=self.index_dtype, device=self.device)

        # 1. Get the ijk of the input primal cubes.
        base_primal_ijks = self.primal_cube_indices_ijk(primal_cube_idx)

        # 2. Find the ijk of the extended dual vertex at the center of each primal cube.
        #    The +1 offset maps from the primal cube grid to the extended dual vertex grid.
        center_dual_v_ijks = base_primal_ijks + 1

        # 3. Find the ijk of the 6 neighboring primal cubes.
        neighbor_primal_ijks = base_primal_ijks.unsqueeze(1) + self._face_neighbor_offsets.unsqueeze(0)
        
        # 4. Find the ijk of the extended dual vertices at the center of the neighbors.
        neighbor_dual_v_ijks = neighbor_primal_ijks + 1

        # 5. Convert all dual vertex ijk coordinates to linear indices.
        #    No boundary check is needed due to the extended grid's halo layer.
        dims = (self.d_ext_num, self.d_ext_num, self.d_ext_num)
        
        center_dual_v_indices = self.ravel_ijk(center_dual_v_ijks, dims)
        
        flat_neighbor_dual_v_ijks = neighbor_dual_v_ijks.view(-1, 3)
        flat_neighbor_indices = self.ravel_ijk(flat_neighbor_dual_v_ijks, dims)
        neighbor_dual_v_indices = flat_neighbor_indices.view(B, 6)
        
        # 6. Create the final pairs.
        center_indices_expanded = center_dual_v_indices.unsqueeze(1).expand(-1, 6)
        pairs = torch.stack([center_indices_expanded, neighbor_dual_v_indices], dim=-1)

        return pairs
    
    
# ===================================================================
#  Octree Indexer with Maximum Level
# ===================================================================

class OctreeIndexer(GridExtent):
    """
    八叉树工具类 (最终修正版)
    修正了 Morton 编码/解码中的位运算bug，确保了转换的可逆性。
    """
    def __init__(self, max_level: int, device: str = "cpu", dtype: torch.dtype = torch.float32):
        if not (0 < max_level <= 21): raise ValueError(f"max_level must be between 1 and 21")
        self.max_level = max_level
        super().__init__(res=(1 << max_level), device=device, dtype=dtype)

    # ====================================================================
    # --- Morton encode/decode ----
    # ====================================================================
    @staticmethod
    def _part1by2(x: torch.Tensor) -> torch.Tensor:
        """Spreads the bits of a 21-bit integer so that there are two zero bits between each original bit."""
        x = x & 0x1fffff
        x = (x | x << 32) & 0x1f00000000ffff
        x = (x | x << 16) & 0x1f0000ff0000ff
        x = (x | x << 8)  & 0x100f00f00f00f00f
        x = (x | x << 4)  & 0x10c30c30c30c30c3
        x = (x | x << 2)  & 0x1249249249249249
        return x

    @staticmethod
    def _compact1by2(x: torch.Tensor) -> torch.Tensor:
        """The inverse of _part1by2, compacting every third bit."""
        x = x & 0x1249249249249249
        x = (x ^ x >> 2)  & 0x10c30c30c30c30c3
        x = (x ^ x >> 4)  & 0x100f00f00f00f00f
        x = (x ^ x >> 8)  & 0x1f0000ff0000ff
        x = (x ^ x >> 16) & 0x1f00000000ffff
        x = (x ^ x >> 32) & 0x1fffff
        return x

    @staticmethod
    def morton_encode(ijk: torch.Tensor) -> torch.Tensor:
        """将 [..., 3] 形式的 (i,j,k) 坐标编码为 Morton 码。"""
        i, j, k = ijk[..., 0].to(torch.int64), ijk[..., 1].to(torch.int64), ijk[..., 2].to(torch.int64)
        return (OctreeIndexer._part1by2(i) | 
                (OctreeIndexer._part1by2(j) << 1) | 
                (OctreeIndexer._part1by2(k) << 2))

    @staticmethod
    def morton_decode(code: torch.Tensor) -> torch.Tensor:
        """将 Morton 码解码为 [..., 3] 形式的 (i,j,k) 坐标。"""
        code = code.to(torch.int64)
        i = OctreeIndexer._compact1by2(code)
        j = OctreeIndexer._compact1by2(code >> 1)
        k = OctreeIndexer._compact1by2(code >> 2)
        return torch.stack([i, j, k], dim=-1)

    # --- 等级感知方法 (无变化) ---
    def primal_cube_indices_ijk(self, cube_idx: Optional[torch.Tensor] = None, level: Optional[int] = None) -> torch.Tensor:
        if level is None: level = self.max_level
        n_level = 1 << level
        if cube_idx is None: cube_idx = torch.arange(n_level**3, device=self.device, dtype=self.index_dtype)
        return self.unravel_idx(cube_idx, dims=(n_level, n_level, n_level))

    def primal_cube_aabbs_minmax(self, cube_idx: Optional[torch.Tensor] = None, level: Optional[int] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        if level is None: level = self.max_level
        n_level = 1 << level; h_level = 2.0 / n_level
        ijk = self.primal_cube_indices_ijk(cube_idx, level=level)
        mins = -1.0 + ijk.to(self.dtype) * h_level
        return mins, mins + h_level

    # --- 其他 Octree 专用方法 (无变化) ---
    def linear_to_morton(self, linear_idx: torch.Tensor, level: int) -> torch.Tensor:
        n = 1 << level
        ijk = self.unravel_idx(linear_idx, dims=(n, n, n))
        return self.morton_encode(ijk)

    def morton_to_linear(self, morton: torch.Tensor, level: int) -> torch.Tensor:
        ijk = self.morton_decode(morton)
        n = 1 << level
        return ijk[..., 0] * n*n + ijk[..., 1] * n + ijk[..., 2]

    def children_morton(self, parent_morton: torch.Tensor) -> torch.Tensor:
        base = parent_morton.unsqueeze(-1).to(torch.int64) << 3
        return base + torch.arange(8, device=self.device, dtype=torch.int64)
    
if __name__ == '__main__':
    # 1. 通过 level 初始化，更直观
    # max_level=7 意味着网格分辨率 res = 2**7 = 128
    indexer = OctreeIndexer(max_level=7, device='cuda')

    a = indexer.primal_cube_aabbs_minmax(level=4)

    indexer = OctreeIndexer(max_level=4, device='cuda')
    
    b = indexer.primal_cube_aabbs_minmax(level=4)

    assert torch.allclose(a[0], b[0]) and torch.allclose(a[1], b[1]), "Mismatch in AABB computation across levels"

    print(a[0], a[1])
    assert 1==2, "stopdasda"

    print(f"Octree Initialized:")
    print(f"  Max Level: {indexer.max_level}")
    print(f"  Resolution (res): {indexer.res}")
    print(f"  Device: {indexer.device}")
    
    # 2. 自动拥有 GridExtent 的所有方法
    print("\nTesting inherited GridExtent method...")
    # 获取索引为 0, 1, 2 的 primal 立方体的包围盒
    some_primal_indices = torch.tensor([0, 1, 2], device=indexer.device)
    mins, maxs = indexer.primal_cube_aabbs_minmax(some_primal_indices)
    print(f"AABBs for primals [0, 1, 2]:\n{mins.cpu().numpy()}")

    # 3. 使用 OctreeIndexer 的特定方法
    print("\nTesting OctreeIndexer specific method...")
    # 将这些 primal 索引转换为 level 5 上的 Morton 码
    morton_codes = indexer.morton_at_level(some_primal_indices, level=5)
    print(f"Morton codes at level 5:\n{morton_codes.cpu().numpy()}")
    
    # 4. 使用强大的父子映射功能
    print("\nTesting Parent-Child mapping...")
    # 获取从 level 2 到 level 3 的所有父子关系
    parent_child_map = indexer.get_parent_child_map(parent_level=2)
    print(f"Parent-child map shape (COO format): {parent_child_map.shape}")
    num_nodes_level2 = (1 << 2)**3
    print(f"Expected number of connections: {num_nodes_level2 * 8}")
    print("Example pairs (child_morton, parent_morton):")
    print(parent_child_map[:, :5].cpu().numpy())